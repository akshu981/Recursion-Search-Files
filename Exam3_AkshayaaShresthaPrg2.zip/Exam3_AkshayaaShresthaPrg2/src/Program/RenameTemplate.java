
package Program;


public class RenameTemplate {
    
    private String chars;
    private int counterLength;
    private int startIndex;
    private int endIndex;
    
    public RenameTemplate(String chars, int counterLength){
        this.chars=chars;
        this.counterLength=counterLength;
    }

    public String getChars() {
        return chars;
    }

    public void setChars(String chars) {
        this.chars = chars;
    }

    public int getCounterLength() {
        return counterLength;
    }

    public void setCounterLength(int counterLength) {
        this.counterLength = counterLength;
    }

    public int getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(int startIndex) {
        this.startIndex = startIndex;
    }

    public int getEndIndex() {
        return endIndex;
    }

    public void setEndIndex(int endIndex) {
        this.endIndex = endIndex;
    }
    
    
}
