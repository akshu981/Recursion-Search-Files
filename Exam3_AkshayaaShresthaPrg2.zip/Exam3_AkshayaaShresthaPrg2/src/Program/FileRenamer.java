package Program;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import org.apache.commons.io.FilenameUtils;


public class FileRenamer {
    
    public ArrayList<File> listFiles= new ArrayList<>();
    public ArrayList<RenameTemplate> arTemplate= new ArrayList<RenameTemplate>();
    
    public String template;
    public String copyFolder;
    public boolean renameCopy;
    public String errorStatus;
    public String successStatus;
    public int startCounter;
    public int failedFileCount;
    public int successFileCount;
    public File dir;
    
    public boolean excludeSubs;
    boolean isSuccess;
    FileFinder finder;
    
    
    
    public FileRenamer(File dir, FileFinder finder, String template, int startCounter, String copyFolder, boolean renameCopy, boolean excludeSubs){
        this.dir= dir;
        this.template= template;
        this.startCounter= startCounter;
        this.copyFolder= copyFolder;
        this.renameCopy= renameCopy;
        this.excludeSubs= excludeSubs;
        
        this.finder= finder;
        
        errorStatus="";
        successStatus="";
        
        try {
            getTemplateArray();
        } catch(Exception ex)
        {
            errorStatus= "Error happened in getTemplateArray method in FileRenamer class";
            isSuccess= false;
            return;
        }
        
        listFiles = finder.getListFiles();
        
        if (excludeSubs)
            renameFiles(finder.getInnerFile());
        else
            renameFiles(finder.getListFiles());
     
    }
    
    private void renameFiles(ArrayList<File> listFiles){
        int iCount= startCounter;
        for (File file : listFiles)
        {
            renameSingleFile( file, iCount);
            iCount ++;
        }
        
        if (failedFileCount > 0)
            errorStatus = failedFileCount + " files were not renamed due to unexpected error";
        else
            successStatus = successFileCount + " files were renamed successfully";
    }
    
    public String createFileName(int iCount){ 
        String newName="";
        for(RenameTemplate temp: arTemplate)
        {
            String sPart= temp.getChars();
            int iCharCount= temp.getCounterLength(); //supplied number of hashes
            String sCounter= "";
            int currentLength= String.valueOf(iCount).length(); //number of digits
            
            if(iCharCount> currentLength)//add leading zeroes
            {
                for(int i=0; i<iCharCount-currentLength;i++ )
                    sCounter+="0";  //if the supplied number of hashes exceeds the number of digits, add zero at the first
            }
            sCounter+=iCount;
            newName+= sPart+sCounter;
        }
        return newName;
    }
    
    public void getTemplateArray(){
        String modifiedTemplate= template;
        
        for(int n=template.length(); n>=1; n--) //starts from the last character
        {
          String replaceString="";
          
          for(int m=n; m>0; m--)
          replaceString+= "#";
          modifiedTemplate=modifiedTemplate.replaceAll(replaceString, "#");
         
        }
        String[] arWords= modifiedTemplate.split("#");
        arTemplate= new ArrayList<RenameTemplate>();
        
        for(int i=0; i<arWords.length; i++)
        {
            int iStart=0;
            int iEnd=0;
            int charCount=0;
            
            if(i==arWords.length-1)
                iEnd= template.length();
            else
                iEnd=template.indexOf(arWords[i+1]);
            
            iStart= template.indexOf(arWords[i])+ arWords[i].length();
            charCount= iEnd-iStart;
            
            arTemplate.add(new RenameTemplate(arWords[i], charCount));
        }
    }
    
    public void renameSingleFile(File file, int iCount){ 
        //iCount replaces the pound signs and file is the file to be renamed
        //the method utilizes fileFinder class to search for files 
        
        String newName= createFileName(iCount);
        
        String ext= FilenameUtils.getExtension(file.getAbsolutePath());
        
        newName+= "." + ext;
        
        File newFile=null;

        //get name
        if (renameCopy)
            newFile = new File(copyFolder + "\\" + newName);
        else
	    newFile = new File(file.getParentFile().getAbsolutePath() + "\\" + newName);

        //make the move
        try 
        {
        if (renameCopy)
           Files.copy(file.toPath(), newFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
        else
	   file.renameTo(newFile);
        
           successFileCount++;
        } 
        
        catch(IOException ex) 
        {
	System.out.println("Error happend when copying " + newName + "to " + copyFolder);
	failedFileCount++;
        }
        
    }

    public ArrayList<File> getListFiles() {
        return listFiles;
    }

    public void setListFiles(ArrayList<File> listFiles) {
        this.listFiles = listFiles;
    }

    public String getErrorStatus() {
        return errorStatus;
    }
    
    
    
}
